CLARITY source update

Contents:
- app/src/main/java/za/co/clarity/Data.kt
- app/src/main/java/za/co/clarity/MainActivity.kt
- app/src/main/AndroidManifest.xml
- app/src/main/res/drawable/ic_clarity_logo.xml

How to use:
1. Extract this ZIP into the ROOT of your existing Clarity repository.
2. Allow the files to merge with/replace the matching paths.
3. Review the changed files, then build and test the APK before installing it.
4. Commit and push the changes from your Codespace.

This update adds:
- Monthly and yearly budget views with all 12 months.
- Persistent month-by-month plans using Room.
- Separate Expense and Income category lists and type-aware custom categories.
- Save error/success feedback for database writes.
- CLARITY app header and launcher branding.

Important:
- Existing Room schema is retained at version 1, so existing local database data is not intentionally reset.
- This source archive has not been built in your Codespace. Run the Android Gradle build there before distributing the APK.
